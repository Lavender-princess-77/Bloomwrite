require('dotenv').config();
const mongoose = require('mongoose');
const User = require('../models/User');
const Post = require('../models/Post');
async function seed(){
  await mongoose.connect(process.env.MONGO_URI || 'mongodb://localhost:27017/bloomwrite');
  await User.deleteMany({});
  await Post.deleteMany({});
  const u = await User.create({username:'demo', email:'demo@demo.com', passwordHash:'', bio:'Welcome to my memory garden!', interests:['stories','poems']});
  await Post.create({author:u._id, title:'First Bloom', content:'This is a demo bloom.', bed:'Story Bed', hashtags:['demo','first'], isDraft:false, publishedAt:new Date()});
  console.log('seeded demo user with id', u._id.toString());
  process.exit(0);
}
seed().catch(e=>{console.error(e);process.exit(1)});
