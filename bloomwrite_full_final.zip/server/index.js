require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const authRoutes = require('./routes/auth');
const postRoutes = require('./routes/posts');
const commentRoutes = require('./routes/comments');
const userRoutes = require('./routes/users');
const gardenRoutes = require('./routes/garden');
const aiRoutes = require('./routes/ai');

const app = express();
app.use(cors());
app.use(express.json());

app.use('/api/auth', authRoutes);
app.use('/api/posts', postRoutes);
app.use('/api/comments', commentRoutes);
app.use('/api/users', userRoutes);
app.use('/api/garden', gardenRoutes);
app.use('/api/ai', aiRoutes);

const PORT = process.env.PORT || 4000;
mongoose.connect(process.env.MONGO_URI || 'mongodb://mongo:27017/bloomwrite').then(()=>{
  console.log('Mongo connected');
  app.listen(PORT, ()=> console.log('Server listening on', PORT));
}).catch(err=>{ console.error('Mongo err', err) });
