const express = require('express');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const User = require('../models/User');
const router = express.Router();

router.post('/register', async (req,res)=>{
  try{
    const {username,email,password,interests=[]} = req.body;
    const hash = await bcrypt.hash(password,10);
    const user = await User.create({username,email,passwordHash:hash,interests});
    const token = jwt.sign({id:user._id}, process.env.JWT_SECRET||'dev', {expiresIn:'7d'});
    res.json({token,user:{id:user._id,username:user.username,email:user.email}});
  }catch(e){ res.status(400).json({error:e.message}); }
});

router.post('/login', async (req,res)=>{
  try{
    const {email,password} = req.body;
    const user = await User.findOne({email});
    if(!user) return res.status(404).json({error:'User not found'});
    const ok = await bcrypt.compare(password, user.passwordHash);
    if(!ok) return res.status(401).json({error:'Invalid credentials'});
    const token = jwt.sign({id:user._id}, process.env.JWT_SECRET||'dev', {expiresIn:'7d'});
    res.json({token,user:{id:user._id,username:user.username,email:user.email}});
  }catch(e){ res.status(400).json({error:e.message}); }
});

module.exports = router;
