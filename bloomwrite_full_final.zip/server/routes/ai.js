const express = require('express');
const axios = require('axios');
const auth = require('../middleware/auth');
const router = express.Router();

// Example: POST /api/ai/suggest {text}
// This is a simple proxy that will call OpenAI if OPENAI_KEY is set in env.
// If not set, it returns canned suggestions.
router.post('/suggest', auth, async (req,res)=>{
  const {text} = req.body;
  if(!process.env.OPENAI_KEY){
    return res.json({titles:['A Bloom of Thoughts','Morning Garden Notes','Whispers in the Canopy'], hashtags:['#bloom','#writing','#garden']});
  }
  try{
    const resp = await axios.post('https://api.openai.com/v1/chat/completions', {
      model:'gpt-4o-mini',
      messages:[{role:'user', content:`Suggest 5 catchy titles and 8 hashtags for this text: ${text}`}],
      max_tokens:200
    }, { headers:{ Authorization:`Bearer ${process.env.OPENAI_KEY}` } });
    return res.json({raw:resp.data});
  }catch(e){ return res.status(500).json({error:'ai error', details:e.message}); }
});

module.exports = router;
