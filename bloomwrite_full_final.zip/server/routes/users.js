const express = require('express');
const User = require('../models/User');
const auth = require('../middleware/auth');
const router = express.Router();

router.get('/:id', async (req,res)=>{
  const u = await User.findById(req.params.id).select('-passwordHash');
  if(!u) return res.status(404).json({error:'no user'});
  res.json(u);
});

router.post('/:id/follow', auth, async (req,res)=>{
  const targetId = req.params.id;
  if(targetId === req.user.id) return res.status(400).json({error:'cannot follow self'});
  await User.findByIdAndUpdate(req.user.id, {$addToSet:{seeds: targetId}});
  await User.findByIdAndUpdate(targetId, {$addToSet:{companions: req.user.id}});
  res.json({ok:true});
});

module.exports = router;
