const express = require('express');
const User = require('../models/User');
const auth = require('../middleware/auth');
const router = express.Router();

router.post('/plant', auth, async (req,res)=>{
  const {species} = req.body;
  const user = await User.findById(req.user.id);
  user.garden.plants.push({species, plantedAt:new Date(), growthProgress:0, nutrients:0});
  await user.save();
  res.json(user.garden);
});

router.post('/care', auth, async (req,res)=>{
  try{
    const {action, plantIndex} = req.body;
    const user = await User.findById(req.user.id);
    const plant = user.garden.plants[plantIndex];
    if(!plant) return res.status(404).json({error:'no plant'});
    const now = new Date();
    let gain = action==='water'?5: action==='trim'?3:8;
    const daysSince = Math.floor((now - (plant.lastCare||plant.plantedAt||now))/(1000*60*60*24));
    if(daysSince>1) gain = Math.max(0,gain-(daysSince-1));
    plant.growthProgress = Math.min(100,(plant.growthProgress||0)+gain);
    plant.lastCare = now;
    await user.save();
    res.json(plant);
  }catch(e){ res.status(400).json({error:e.message})}
});

router.get('/', auth, async (req,res)=>{
  const user = await User.findById(req.user.id);
  res.json(user.garden);
});

module.exports = router;
