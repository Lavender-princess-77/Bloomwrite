const express = require('express');
const Post = require('../models/Post');
const User = require('../models/User');
const auth = require('../middleware/auth');
const router = express.Router();

router.post('/', auth, async (req,res)=>{
  try{
    const {title,content,bed,hashtags,images} = req.body;
    const p = await Post.create({author:req.user.id,title,content,bed,hashtags,images,isDraft:false,publishedAt:new Date()});
    await User.findByIdAndUpdate(req.user.id, {$inc:{'stats.bloomsCount':1}});
    res.json(p);
  }catch(e){ res.status(400).json({error:e.message})}
});

router.get('/', async (req,res)=>{
  const q = req.query.q;
  let filter = {};
  if(q) filter.$or = [{title: new RegExp(q,'i')}, {content: new RegExp(q,'i')}, {hashtags: new RegExp(q,'i')}];
  const list = await Post.find(filter).sort({createdAt:-1}).limit(100).populate('author','username profilePic');
  res.json(list);
});

router.get('/:id', async (req,res)=>{
  const p = await Post.findById(req.params.id).populate('author','username profilePic');
  if(!p) return res.status(404).json({error:'Not found'});
  p.views = (p.views||0)+1;
  await p.save();
  res.json(p);
});

module.exports = router;
