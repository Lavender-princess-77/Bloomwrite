const express = require('express');
const Comment = require('../models/Comment');
const Post = require('../models/Post');
const auth = require('../middleware/auth');
const router = express.Router();

router.post('/:postId', auth, async (req,res)=>{
  try{
    const {content, parent} = req.body;
    const c = await Comment.create({post:req.params.postId, author:req.user.id, content, parent});
    await Post.findByIdAndUpdate(req.params.postId, {$inc:{notesCount:1}});
    res.json(c);
  }catch(e){ res.status(400).json({error:e.message})}
});

module.exports = router;
