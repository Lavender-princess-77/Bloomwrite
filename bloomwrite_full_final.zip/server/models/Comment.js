const mongoose = require('mongoose');
const CommentSchema = new mongoose.Schema({
  post:{type: mongoose.Schema.Types.ObjectId, ref:'Post'},
  author:{type: mongoose.Schema.Types.ObjectId, ref:'User'},
  content:String,
  parent:{type: mongoose.Schema.Types.ObjectId, ref:'Comment'}
},{timestamps:true});
module.exports = mongoose.model('Comment', CommentSchema);
