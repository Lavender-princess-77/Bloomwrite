const mongoose = require('mongoose');
const UserSchema = new mongoose.Schema({
  username:{type:String,unique:true,required:true},
  email:{type:String,unique:true,required:true},
  passwordHash:String,
  profilePic:String,
  canopy:String,
  bio:String,
  interests:[String],
  companions:[{type: mongoose.Schema.Types.ObjectId, ref:'User'}],
  seeds:[{type: mongoose.Schema.Types.ObjectId, ref:'User'}],
  garden:{ plants:[{ species:String, plantedAt:Date, growthProgress:Number, lastCare:Date, nutrients:Number }] },
  stats:{ bloomsCount:{type:Number,default:0}, sunbeams:{type:Number,default:0}, views:{type:Number,default:0} }
},{timestamps:true});
module.exports = mongoose.model('User', UserSchema);
