const mongoose = require('mongoose');
const PostSchema = new mongoose.Schema({
  author:{type: mongoose.Schema.Types.ObjectId, ref:'User'},
  title:String,
  content:String,
  images:[String],
  hashtags:[String],
  bed:String,
  sunbeams:{type:Number,default:0},
  notesCount:{type:Number,default:0},
  views:{type:Number,default:0},
  isDraft:{type:Boolean,default:true},
  publishedAt:Date
},{timestamps:true});
module.exports = mongoose.model('Post', PostSchema);
