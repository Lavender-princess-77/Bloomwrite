import React from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { isLoggedIn, clearToken } from '../utils/auth'

export default function NavBar(){
  const nav = useNavigate();
  const logged = isLoggedIn();
  function logout(){ clearToken(); nav('/'); }
  return (
    <header className="w-full bg-white/60 backdrop-blur p-3 flex items-center justify-between">
      <div className="flex items-center gap-4">
        <Link to="/home" className="font-bold text-emerald-700">BloomWrite</Link>
        <Link to="/explore" className="text-sm text-gray-700">Explore</Link>
        <Link to="/communities" className="text-sm text-gray-700">Communities</Link>
      </div>
      <div className="flex items-center gap-3">
        {logged ? (
          <>
            <Link to="/garden" className="text-sm text-gray-700">My Garden</Link>
            <button onClick={logout} className="px-3 py-1 rounded border text-sm">Logout</button>
          </>
        ) : (
          <Link to="/" className="px-3 py-1 rounded border text-sm">Login</Link>
        )}
      </div>
    </header>
  )
}
