import React from 'react'
import { createRoot } from 'react-dom/client'
import { BrowserRouter, Routes, Route } from 'react-router-dom'
import Login from './pages/Login'
import Home from './pages/Home'
import Explore from './pages/Explore'
import Editor from './pages/Editor'
import Profile from './pages/Profile'
import Garden from './pages/Garden'
import Communities from './pages/Communities'
import NavBar from './components/NavBar'
import ProtectedRoute from './components/ProtectedRoute'
import './index.css'

function App(){
  return (
    <BrowserRouter>
      <NavBar />
      <Routes>
        <Route path='/' element={<Login/>} />
        <Route path='/home' element={<ProtectedRoute><Home/></ProtectedRoute>} />
        <Route path='/explore' element={<ProtectedRoute><Explore/></ProtectedRoute>} />
        <Route path='/editor' element={<ProtectedRoute><Editor/></ProtectedRoute>} />
        <Route path='/profile/:id' element={<ProtectedRoute><Profile/></ProtectedRoute>} />
        <Route path='/garden' element={<ProtectedRoute><Garden/></ProtectedRoute>} />
        <Route path='/communities' element={<ProtectedRoute><Communities/></ProtectedRoute>} />
      </Routes>
    </BrowserRouter>
  )
}

createRoot(document.getElementById('root')).render(<App />)
