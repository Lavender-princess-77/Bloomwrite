export function saveToken(token){ localStorage.setItem('bw_token', token); }
export function clearToken(){ localStorage.removeItem('bw_token'); }
export function getToken(){ return localStorage.getItem('bw_token'); }
export function isLoggedIn(){ return !!getToken(); }
