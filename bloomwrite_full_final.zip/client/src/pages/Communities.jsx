import React from 'react'

export default function Communities(){
  return (
    <div className="min-h-screen p-8">
      <h2 className="text-xl font-bold text-emerald-700">Garden Rooms</h2>
      <p className="mt-3 text-gray-600">Join interest-based communities, host meetups and challenges.</p>
    </div>
  )
}
