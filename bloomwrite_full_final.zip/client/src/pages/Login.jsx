import React, {useState, useEffect} from 'react'
import { useNavigate } from 'react-router-dom'
import API from '../utils/api'
import { saveToken } from '../utils/auth'

const QUOTES = [
  "Unleash your creativity — plant a thought.",
  "Words are seeds; nurture them daily.",
  "Write a little. Grow a lot.",
  "Plant your words. Grow your world."
];

export default function Login(){
  const nav = useNavigate();
  const [mode,setMode] = useState('login'); // login or register
  const [form,setForm] = useState({email:'',username:'',password:''});
  const [quote,setQuote] = useState(QUOTES[0]);

  useEffect(()=>{
    const t = setInterval(()=> setQuote(QUOTES[Math.floor(Math.random()*QUOTES.length)]), 4000);
    return ()=> clearInterval(t);
  },[]);

  async function submit(e){
    e.preventDefault();
    try{
      if(mode==='register'){
        const resp = await API.post('/api/auth/register', {username: form.username, email: form.email, password: form.password, interests:[]});
        saveToken(resp.data.token);
      }else{
        const resp = await API.post('/api/auth/login', {email: form.email, password: form.password});
        saveToken(resp.data.token);
      }
      nav('/home');
    }catch(err){ alert(err.response?.data?.error || err.message) }
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-6 relative overflow-hidden">
      {/* background svg */}
      <img src="/assets/garden_bg.svg" alt="garden" className="pointer-events-none absolute inset-0 w-full h-full object-cover opacity-90" />
      <div className="relative z-10 max-w-3xl w-full grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
        <div className="p-8 bg-white/85 backdrop-blur-md rounded-2xl shadow-md">
          <h1 className="text-3xl font-extrabold text-emerald-800">BloomWrite</h1>
          <p className="mt-2 text-sm text-gray-700"> <em>{quote}</em> </p>
          <form onSubmit={submit} className="mt-6 space-y-3">
            <input className="w-full p-3 rounded-lg border" placeholder="Email" value={form.email} onChange={e=>setForm({...form,email:e.target.value})} required />
            {mode==='register' && <input className="w-full p-3 rounded-lg border" placeholder="Username" value={form.username} onChange={e=>setForm({...form,username:e.target.value})} required />}
            <input className="w-full p-3 rounded-lg border" placeholder="Password" type="password" value={form.password} onChange={e=>setForm({...form,password:e.target.value})} required />
            <button className="w-full p-3 rounded-lg bg-emerald-600 text-white font-semibold">{mode==='register' ? 'Create account' : 'Start Creating'}</button>
          </form>
          <div className="mt-3 text-sm text-center text-gray-500">
            <button onClick={()=>setMode(mode==='register'?'login':'register')} className="underline">{mode==='register' ? 'Already have an account? Login' : 'New? Create account'}</button>
          </div>
        </div>
        <div className="p-6 rounded-2xl flex flex-col justify-between text-right bg-white/60">
          <div>
            <h2 className="text-xl font-bold text-emerald-700">Grow your world.</h2>
            <p className="mt-3 text-gray-600">A cozy place for stories, poems, life notes, and playful garden games.</p>
          </div>
          <div className="mt-6">
            <button onClick={()=>nav('/editor')} className="p-3 rounded-lg border border-emerald-200">Try the Editor</button>
          </div>
        </div>
      </div>
    </div>
  )
}
