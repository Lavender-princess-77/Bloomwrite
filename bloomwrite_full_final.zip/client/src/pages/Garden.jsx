import React, {useEffect, useState} from 'react'
import API from '../utils/api'

export default function Garden(){
  const [garden,setGarden] = useState({plants:[]});
  const [species,setSpecies] = useState('Sunflower');

  useEffect(()=>{ load() },[]);

  async function load(){
    try{ const r = await API.get('/api/garden'); setGarden(r.data); }catch(e){ console.error(e) }
  }
  async function plant(){
    try{ await API.post('/api/garden/plant', {species}); load(); }catch(e){ alert('Plant failed') }
  }
  async function care(i,action){
    try{ await API.post('/api/garden/care', {plantIndex:i, action}); load(); }catch(e){ alert('Action failed') }
  }

  return (
    <div className="min-h-screen p-8">
      <h2 className="text-xl font-bold text-emerald-700">Your Memory Garden</h2>
      <div className="mt-4 p-6 bg-white rounded shadow">
        <div className="flex items-center gap-3">
          <input value={species} onChange={e=>setSpecies(e.target.value)} className="p-2 border rounded" />
          <button onClick={plant} className="px-3 py-2 rounded bg-emerald-600 text-white">Plant</button>
        </div>
        <div className="mt-4 grid grid-cols-1 md:grid-cols-3 gap-4">
          {garden.plants?.length===0 && <div className="text-gray-500">No plants yet — plant one to start nurturing!</div>}
          {garden.plants?.map((p,idx)=> (
            <div key={idx} className="p-4 border rounded">
              <div className="flex justify-between items-center">
                <strong>{p.species}</strong>
                <span className="text-sm text-gray-500">{p.growthProgress||0}%</span>
              </div>
              <div className="mt-3 flex gap-2">
                <button onClick={()=>care(idx,'water')} className="px-2 py-1 rounded border text-sm">Water</button>
                <button onClick={()=>care(idx,'trim')} className="px-2 py-1 rounded border text-sm">Trim</button>
                <button onClick={()=>care(idx,'post')} className="px-2 py-1 rounded border text-sm">Post</button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
