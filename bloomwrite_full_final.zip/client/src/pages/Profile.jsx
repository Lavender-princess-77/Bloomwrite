import React from 'react'
import { useParams } from 'react-router-dom'

export default function Profile(){
  const {id} = useParams()
  return (
    <div className="min-h-screen p-8">
      <div className="p-6 bg-white rounded-lg shadow">
        <h2 className="text-2xl font-bold">Gardeners Profile</h2>
        <p className="text-sm text-gray-600">Analytics, Canopy, Companions, Blooms</p>
      </div>
    </div>
  )
}
