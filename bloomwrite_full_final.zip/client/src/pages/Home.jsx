import React, {useEffect, useState} from 'react'
import { Link } from 'react-router-dom'
import API from '../utils/api'

export default function Home(){
  const [posts,setPosts] = useState([]);

  useEffect(()=>{ fetchPosts() },[]);

  async function fetchPosts(){
    try{ const r = await API.get('/api/posts'); setPosts(r.data); }catch(e){ console.error(e) }
  }

  return (
    <div className="min-h-screen p-8">
      <header className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-emerald-700">BloomWrite — Home</h1>
        <nav className="space-x-4">
          <Link to="/explore" className="text-sm text-gray-700">Explore</Link>
          <Link to="/editor" className="text-sm text-gray-700">Create</Link>
          <Link to="/garden" className="text-sm text-gray-700">Garden</Link>
          <Link to="/communities" className="text-sm text-gray-700">Communities</Link>
        </nav>
      </header>
      <main className="mt-8">
        <section className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="md:col-span-2 p-6 bg-white rounded-lg shadow">
            <h2 className="font-semibold mb-4">Recommended Blooms</h2>
            {posts.length===0 && <div className="text-gray-500">No blooms yet — publish your first one!</div>}
            <div className="space-y-4">
              {posts.map(p=> (
                <article key={p._id} className="p-4 border rounded">
                  <div className="flex items-center justify-between"><strong>{p.title}</strong><span className="text-sm text-gray-500">{new Date(p.publishedAt).toLocaleDateString()}</span></div>
                  <p className="mt-2 text-sm text-gray-700">{p.content?.substring(0,200) || ''}</p>
                </article>
              ))}
            </div>
          </div>
          <aside className="p-6 bg-white rounded-lg shadow">
            <h3 className="font-semibold">Trends & Topics</h3>
            <div className="mt-3 space-y-2">
              <div className="text-sm text-gray-600">#bloom #writing #poems</div>
            </div>
          </aside>
        </section>
      </main>
    </div>
  )
}
