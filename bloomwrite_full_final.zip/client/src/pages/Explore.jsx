import React from 'react'

export default function Explore(){
  return (
    <div className="min-h-screen p-8">
      <h2 className="text-xl font-bold text-emerald-700">Explore — Beds & Blooms</h2>
      <div className="mt-4 grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="p-4 bg-white rounded shadow">Story Bed</div>
        <div className="p-4 bg-white rounded shadow">Poem Bed</div>
        <div className="p-4 bg-white rounded shadow">Daily Life Bed</div>
      </div>
    </div>
  )
}
