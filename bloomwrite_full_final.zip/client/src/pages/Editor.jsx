import React, {useState} from 'react'
import { useNavigate } from 'react-router-dom'
import API from '../utils/api'
export default function Editor(){
  const nav = useNavigate()
  const [title,setTitle] = useState('')
  const [content,setContent] = useState('')

  async function publish(){
    try{
      await API.post('/api/posts', {title, content, bed:'Story Bed', hashtags: []});
      alert('Published!'); nav('/home');
    }catch(e){ alert('Publish failed: '+(e.response?.data?.error||e.message)) }
  }

  return (
    <div className="min-h-screen p-8">
      <header className="flex justify-between items-center">
        <h2 className="text-lg font-bold text-emerald-700">Nurture a Bloom</h2>
        <button onClick={()=>nav('/home')} className="text-sm text-gray-600">Back</button>
      </header>
      <div className="mt-6 p-6 bg-white rounded-lg shadow">
        <input placeholder="Title" className="w-full p-3 border rounded mb-3" value={title} onChange={e=>setTitle(e.target.value)} />
        <textarea placeholder="Write your Bloom..." className="w-full p-3 border rounded h-56" value={content} onChange={e=>setContent(e.target.value)} />
        <div className="flex items-center justify-between mt-4">
          <div className="text-sm text-gray-500">Add images, hashtags, choose Bed</div>
          <div className="space-x-2">
            <button className="px-4 py-2 rounded border">Save Draft</button>
            <button onClick={publish} className="px-4 py-2 rounded bg-emerald-600 text-white">Publish</button>
          </div>
        </div>
      </div>
    </div>
  )
}
