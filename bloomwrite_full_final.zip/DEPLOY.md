# Deploying BloomWrite — Step-by-step

## Environment variables required (server)
- MONGO_URI
- JWT_SECRET
- OPENAI_KEY (optional)
- CLOUDINARY_CLOUDNAME (client)
- CLOUDINARY_PRESET (client)

## Quick deploy to Render (server) + Vercel (client)

### 1) Push code to GitHub
git init
git add .
git commit -m "Initial BloomWrite"
git branch -M main
git remote add origin https://github.com/<your-username>/bloomwrite.git
git push -u origin main

### 2) Deploy server to Render
- Create a new Web Service on Render, connect your GitHub repo, set build command `npm install` and start command `node index.js` in /server.
- Set the environment variables.

### 3) Deploy client to Vercel
- Create a new project in Vercel, import your GitHub repo, point to the client/ directory as root.
- Set Environment Variable: `VITE_API_URL` to your server URL.

